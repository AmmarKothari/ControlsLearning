simiam
======

A MATLAB-based Educational Bridge Between Theory and Practice in Robotics.